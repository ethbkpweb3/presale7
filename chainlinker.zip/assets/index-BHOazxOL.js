import{a6 as r,af as s,a0 as i,ab as t,ah as n,ai as f,aj as d,a7 as c,ae as l,aa as m,ac as h,ad as p,ag as I,a8 as x,a9 as w}from"./index-CpP-AC1q.js";const a=`
@font-face {
  font-family: 'Inter';
  font-style:  normal;
  font-weight: 300 600;
  font-display: swap;
  src: url("https://rsms.me/inter/font-files/InterVariable.woff2") format("woff2-variations");
}
`;export{a as InterVar,r as ProviderRpcError,s as ProviderRpcErrorCode,i as bigIntToHex,t as chainIdToViemImport,n as chainIdValidation,f as chainNamespaceValidation,d as chainValidation,c as createEIP1193Provider,l as fromHex,m as isAddress,h as isHex,p as toHex,I as validate,x as weiHexToEth,w as weiToEth};